import sys

def transform_Reciepes(reciepes_df,spark) :
    try:
        reciepes_df.createOrReplaceTempView("temp_reciepes")
    except Exception as e:
        print("read in_view_creation",e.__class__,"occured")
        sys.exit(1)
    try:
        beef_df=spark.sql("""select name from temp_reciepes where upper(ingredients) like '%BEEF%'""").show(10,False)
    except Exception as e:
        print("Error on Beef_df",e.__class__,"occured")
        sys.exit(1)
    
    try:
        difficulty_df=spark.sql("""select difficulty,(tot_per_diff/num) as avg_total_cooking_time from(select difficulty,
        sum(tot_time) as tot_per_diff,count(name) as num from(select name,ingredients,
        (time_conv(perpTime)+time_conv(cookTime)) as tot_time,
        case when (time_conv(perpTime)+time_conv(cookTime)) < 30 then 'Easy'
        when (time_conv(perpTime)+time_conv(cookTime)) = 30 or (time_conv(perpTime)+time_conv(cookTime)) >30 and
        (time_conv(perpTime)+time_conv(cookTime)) <60 then 'Medium'
        when (time_conv(perpTime)+time_conv(cookTime)) > 50 then 'Hard' end as difficulty
        temp_reciepes where upper(ingredients) like '%BEEF%')x group by difficulty)y """)
        return difficulty_df
    except Exception as e:
        print("Error on difficulty_df",e.__class__,"occured")
        sys.exit(1)