import sys

def read_Reciepes(file_name,read_file_format,spark) :
    try:
        reciepes_df=spark.read.format(read_file_format).options('inferSchema','true').option('header','true').load(file_name)
        return reciepes_df
    except Exception as e:
        print("read error",e.__class__,"occured")
        sys.exit(1)